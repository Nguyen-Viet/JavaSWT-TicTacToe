package presentation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.*;

/**
 * This class act as a frame that holds all the widget.
 * @author 636494 - Viet Nguyen
 *
 */
public class TicTacToeGUI 
{
	
	 private JFrame 			gameFrame;
	 private JLabel 			header;
	 private JPanel 			headerPanel;
	 private GamePanel 			tic_tac_toe;
	 private ChatClient 		chatBox;
	 
	 
	 public TicTacToeGUI()
	 {
		 gameFrame = new JFrame(); 
	 }
	 
	
	/*
	 * This method will setup the game
	 */
	public void go()
	{
		//define frame boundaries 
		gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameFrame.setSize(800, 600);
		gameFrame.setVisible(true);
		gameFrame.setTitle("TIC TAC TOE");
		
		//just a header for the application 
		headerPanel = new JPanel();
		headerPanel.setBackground(Color.orange);
		header = new JLabel("TIC - TAC - TOE");
		headerPanel.add(header);
		
		//Instantiate our widget that we created
		tic_tac_toe = new GamePanel();
		chatBox = new ChatClient();
		
		 
		//add those widget into the frame
		gameFrame.getContentPane().add(BorderLayout.NORTH, headerPanel);
		gameFrame.getContentPane().add(BorderLayout.CENTER, tic_tac_toe);
		gameFrame.getContentPane().add(BorderLayout.EAST, chatBox);
	}
	

}//end
