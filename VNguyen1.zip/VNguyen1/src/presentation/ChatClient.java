package presentation;
import utilities.InputListener;
import utilities.Message;
import utilities.XO;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;

import javax.swing.*;

/**
 * Represents the chat area for player
 * @author Viet Nguyen
 * 
*/
public class ChatClient extends JPanel implements Observer  {
	
	//the outer chat panel
	private JPanel 				chat_Panel;
	
	//component used for message chat box
	private JTextArea 			incoming_text;
	private JTextField 			outgoing_text;
	private JButton 			sendButton;
	private JButton				connectButton;
	private JButton				disconnectButton;
	private JScrollPane 		scroller;
	private JPanel 				inner_chat_panel;
	private JLabel 				outgoing_Label;
	
	//component used for connection
	private PrintWriter 		write;
	private String				userName;
	private static ObjectOutputStream	oos;
	private Socket 				socket;
	private InputListener 		inputListner;
	
	
	
	/**
	 * Set up for a nested panel
	 */
	public ChatClient()
	{	
		
		//structure for nested panel
		this.setLayout(new BorderLayout());
		this.setBackground(Color.LIGHT_GRAY);
		
		chat_Panel = new JPanel();
		chat_Panel.setLayout(new BoxLayout(chat_Panel, BoxLayout.Y_AXIS));
		
		setup_ChatBox();
		
		this.add(BorderLayout.EAST , chat_Panel);
		this.add(BorderLayout.CENTER, new JPanel() );
		
	}
	
	
	/**
	 * Create GUI component and add it to the inner panel.
	 * Then add inner panel to the main panel.
	 */
	private void setup_ChatBox() 
	{
		
		//**************Outer chat panel component*************************
		incoming_text = new JTextArea(15, 30);
		incoming_text.setLineWrap(true);
		incoming_text.setWrapStyleWord(true);
		incoming_text.setEditable(false);
		incoming_text.setBorder(BorderFactory.createEmptyBorder());
		
		scroller = new JScrollPane(incoming_text);
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		//**************Inner chat panel component*************************
		sendButton = new JButton("Send");
		sendButton.setEnabled(false);
		sendButton.addActionListener( new SendButtonListener() );
		
		connectButton = new JButton("Connect");
		connectButton.addActionListener( new ConnectButtonListener() );
		
		disconnectButton = new JButton("Disconnect");
		disconnectButton.setEnabled(false);
		disconnectButton.addActionListener( new DisconnectButtonListener() );
		
		outgoing_text = new JTextField(20);
		outgoing_Label = new JLabel("Say: ");
		
		inner_chat_panel = new JPanel();
		inner_chat_panel.setLayout( new FlowLayout() );
		
		inner_chat_panel.add(outgoing_Label);
		inner_chat_panel.add(outgoing_text);
		inner_chat_panel.add(sendButton);
		inner_chat_panel.add(connectButton);
		inner_chat_panel.add(disconnectButton);
		
		//add incoming and outgoing components
		chat_Panel.add(scroller);
		chat_Panel.add(inner_chat_panel);
		
	}
	
	
	/**
	 * Every message sent create an instance of message, and send it into the stream for processing, so
	 * that the other player may see our messages.
	 * The server will send back the message to the other player's incoming screen.
	 * Then append on our message so that we may see what we have wrote. 
	 * 
	 */
	private void sendIt()
	{

		Message message = new Message( userName, outgoing_text.getText(), new Date() );
		
		try
		{
			//implicitly calls the run() from InputListener
			oos.writeObject(message);
			incoming_text.append( "Me: " + message.getMessage() +"\t\t"+ message.getLoggedTime() + "\n" );
			outgoing_text.setText("");
		
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}//close sendIt
	
	public static void sendXO(XO newXo){
		
		try {
			oos.writeObject(newXo);
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	
	
	/**
	 * This method runs when player hit connect. It sets up the network, for
	 * the player by opening up a socket to TCP port 5555.
	 * It then create a connection link and sets up for the observer, observable pattern.
	 * Afterward, create a Thread for this player. 
	 * 
	 */
	private void setUpNetworking()
	{
	
		try 
		{
			socket = new Socket("localhost", 5555);
			
			userName = JOptionPane.showInputDialog("Enter username to begin");
			
			connectButton.setEnabled(false);
			
			oos = new ObjectOutputStream( socket.getOutputStream() );
			incoming_text.append("Connected! Waiting for oppnent\n");
			
			//(setting up for observer, observable pattern)
			inputListner = new InputListener(socket,this);
			
			//every time .writeOject is used call run().
			Thread thread = new Thread(inputListner);
			thread.start();
			
		}
		catch(HeadlessException e)
		{
			e.printStackTrace();
		}
		catch (UnknownHostException e) 
		{
				e.printStackTrace();
		} 
		catch (IOException e) 
		{
				e.printStackTrace();
		}
		
	}//close setUpNetworking
	
	
	/**
	 * When the player disconnect set all button except connect to false, and
	 * close all connection links to the server.
	 */
	private void disconnect()
	{
			//confirmed that you have disconnected
			incoming_text.append("You have disconnected.\n");
			sendButton.setEnabled(false);
			connectButton.setEnabled(true);
			disconnectButton.setEnabled(false);
		try
		{
			oos.close();
			socket.close();
			inputListner = null;
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}//close disconnect
	

	/**
	 * When setChange() and notifyObserver() is called, update is then called.
	 * Get the object from the stream and cast it back as an instance of Message.
	 * This method will then output messages to the player's screen.
	 * @param Observable
	 * @param Object the message from the stream
	 */
	@Override
	public void update(Observable ob, Object o) 
	{
		
		if(o.getClass() == XO.class)
		{
			XO xo = (XO) o;
			JButton btn = GamePanel.getBtn(xo.getBtnName());
			GamePanel.updateButton(btn);
		}
		
		
		if(o.getClass() == Message.class)
		{
		
			Message message = (Message)o;
			String msg = message.getUser() + ": " +
						 message.getMessage();
			
			incoming_text.append(msg + "\n");
			
			
			if(message.getMessage().compareTo("You can start chatting!") == 0)
			{
				sendButton.setEnabled(true);
				disconnectButton.setEnabled(true);
			}
			
			
			if(message.getMessage().compareTo("has disconnected.") == 0)
			{
				//confirm that i have disconnected
				disconnect();
				//prepare for a new game
				setUpNetworking();
			}
		}
	}
	
	/********************************************* MY ACTIONLISTENER *********************************************/
	public class SendButtonListener implements ActionListener
	{
		
		@Override
		public void actionPerformed(ActionEvent event) 
		{
			sendIt();
		}
	}//close inner class
	
	
	
	
	public class ConnectButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			setUpNetworking();
		}
	}//close inner class
	
	
	
	
	public class DisconnectButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			
			Message message = new Message(userName, "has disconnected.", new Date() );
			
			try
			{
				//goes to InputListener
				oos.writeObject(message);
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
			
			
		}
	}//close inner class

	/*************************************************************************************************************/
	
}//end
