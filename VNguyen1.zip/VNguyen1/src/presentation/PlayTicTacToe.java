package presentation;
/**
 * 
 * @author 636494 - Viet Nguyen
 *
 */
public class PlayTicTacToe {

	public static void main(String[] args) 
	{
		
		TicTacToeGUI playGame = new TicTacToeGUI();
		//LET THE GAME BEGIN!
		playGame.go();

	}

}
