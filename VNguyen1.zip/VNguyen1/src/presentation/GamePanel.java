package presentation;

import javax.swing.*;

import utilities.*;
import serverSide.*;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.*;


/**
 * 
 * @author 636494 - Viet Nguyen
 *
 */
public class GamePanel extends JPanel {
	
	private JPanel gamePanel = new JPanel();

	//my buttons
	private JButton btn1;
	private JButton btn2;
	private JButton btn3;
	
	private JButton btn4;
	private JButton btn5;
	private JButton btn6;
	
	private JButton btn7;
	private JButton btn8;
	private JButton btn9;
	
	
	private static String			xo;
	private static int 				num_of_turns = 0;
	private final int				MAX_TURN = 9;
	
	//win condition variable 
	private boolean					tie;
	private boolean					player1Win;
	private boolean					player2Win;
	
	private Socket 					socket;
	private ObjectOutputStream		oos;
	
	
	public static ArrayList<JButton> btnList = new ArrayList<JButton>(9);

	public GamePanel()
	{
		this.setBackground(Color.BLUE);
		this.setLayout(new GridLayout(3,3));
		
		
		
		readyBtn();
		addComponent();
		
	}
	
	public void addComponent()
	{
		this.add(btn1);
		this.add(btn2);
		this.add(btn3);
		
		this.add(btn4);
		this.add(btn5);
		this.add(btn6);
		
		this.add(btn7);
		this.add(btn8);
		this.add(btn9);
	}
	
	public void readyBtn()
	{
		btn1 = new JButton("1");
		btn1.addActionListener( new ButtonListener() );
		btn1.setName("btn1");
		btnList.add(btn1);
		
		btn2 = new JButton("2");
		btn2.addActionListener( new ButtonListener() );
		btnList.add(btn2);
		btn2.setName("btn2");
		
		btn3 = new JButton("3");
		btn3.addActionListener( new ButtonListener() );
		btnList.add(btn3);
		btn3.setName("btn3");
		
		btn4 = new JButton("4");
		btn4.addActionListener( new ButtonListener() );
		btnList.add(btn4);
		btn4.setName("btn4");
		
		btn5 = new JButton("5");
		btn5.addActionListener( new ButtonListener() );
		btnList.add(btn5);
		btn5.setName("btn5");
		
		btn6 = new JButton("6");
		btn6.addActionListener( new ButtonListener() );
		btnList.add(btn6);
		btn6.setName("btn6");
		
		btn7 = new JButton("7");
		btn7.addActionListener( new ButtonListener() );
		btnList.add(btn7);
		btn7.setName("btn7");
		
		btn8 = new JButton("8");
		btn8.addActionListener( new ButtonListener() );
		btnList.add(btn8);
		btn8.setName("btn8");
		
		btn9 = new JButton("9");
		btn9.addActionListener( new ButtonListener() );
		btnList.add(btn9);
		btn9.setName("btn9");
	}
	
	
	public void playIt()
	{
		
	}
	
	public void refresh()
	{
		btn1.setText("");
		btn1.setEnabled(true);
		
		btn2.setText("");
		btn2.setEnabled(true);
		
		btn3.setText("");
		btn3.setEnabled(true);
		
		btn4.setText("");
		btn4.setEnabled(true);
		
		btn5.setText("");
		btn5.setEnabled(true);
		
		btn6.setText("");
		btn6.setEnabled(true);
		
		btn7.setText("");
		btn7.setEnabled(true);
		
		btn8.setText("");
		btn8.setEnabled(true);
		
		btn9.setText("");
		btn9.setEnabled(true);
		
		num_of_turns = 0;
		player1Win = false;
		player2Win = false;
		tie = false;
		
		
	}
	
	
	public void winCondition() 
	{
		horizontalWin();
		
		if(player1Win != true && player2Win != true )
		{
			verticalWin();
			
			if(player1Win != true && player2Win != true)
			{
				diagonalWin();
				
				if(player1Win != true && player2Win != true && num_of_turns == MAX_TURN)
				{
					tie = true;
				}
			}

		}
		
		
		if(player1Win)
		{
			JOptionPane.showMessageDialog(null, "Player 1 WIN!");
		
		}else if(player2Win)
		{
			JOptionPane.showMessageDialog(null, "Player 2 WIN!");
		}
		else if(tie)
		{
			JOptionPane.showMessageDialog(null, "TIE GAME");
		}
		else
		{
			return;
		}
		
		//restart the board
		if(player1Win || player2Win || tie);
		refresh();
		
	}
	
	private void diagonalWin() 
	{
		//*********************************  win condition for 'X'  ***********************************//
		if( btn1.getText().equals("X") && 
			btn5.getText().equals("X") && 
			btn9.getText().equals("X") )
		{
			player1Win = true;
		}
		else if( btn3.getText().equals("X") &&
				 btn5.getText().equals("X") && 
				 btn7.getText().equals("X") )
		{
			player1Win = true;
		}
		//*********************************  win condition for 'O'  ***********************************//
		else if( btn1.getText().equals("O") &&
				 btn5.getText().equals("O") &&
				 btn9.getText().equals("O") )
		{
			player2Win = true;
		}
		else if( btn3.getText().equals("O") &&
				 btn5.getText().equals("O") &&
				 btn7.getText().equals("O") )
		{
			player2Win = true;
		}
		else
		{
			player1Win = false;
			player2Win = false;
		}

		
	}

	private void verticalWin() 
	{
		//*********************************  win condition for 'X'  ***********************************//
		if( btn1.getText().equals("X") && 
			btn4.getText().equals("X") && 
			btn7.getText().equals("X") )
		{
			player1Win = true;
		}
		else if( btn2.getText().equals("X") &&
				 btn5.getText().equals("X") && 
				 btn8.getText().equals("X") )
		{
			player1Win = true;
		}
		else if( btn3.getText().equals("X") &&
				 btn6.getText().equals("X") &&
				 btn9.getText().equals("X") )
		{
			player1Win = true;
		}
		//*********************************  win condition for 'O'  ***********************************//
		else if( btn1.getText().equals("O") &&
				 btn4.getText().equals("O") &&
				 btn7.getText().equals("O") )
		{
			player2Win = true;
		}
		else if( btn2.getText().equals("O") &&
				 btn5.getText().equals("O") &&
				 btn8.getText().equals("O") )
		{
			player2Win = true;
		}
		else if( btn3.getText().equals("O") &&
				 btn6.getText().equals("O") &&
				 btn9.getText().equals("O") )
		{
			player2Win = true;
		}
		else
		{
			player1Win = false;
			player2Win = false;
		}
		
	}

	public void horizontalWin()
	{
		//*********************************  win condition for 'X'  ***********************************//
		if( btn1.getText().equals("X") && 
			btn2.getText().equals("X") && 
			btn3.getText().equals("X") )
		{
			player1Win = true;
		}
		else if( btn4.getText().equals("X") &&
				 btn5.getText().equals("X") && 
				 btn6.getText().equals("X") )
		{
			player1Win = true;
		}
		else if( btn7.getText().equals("X") &&
				 btn8.getText().equals("X") &&
				 btn9.getText().equals("X") )
		{
			player1Win = true;
		}
		//*********************************  win condition for 'O'  ***********************************//
		else if( btn1.getText().equals("O") &&
				 btn2.getText().equals("O") &&
				 btn3.getText().equals("O") )
		{
			player2Win = true;
		}
		else if( btn4.getText().equals("O") &&
				 btn5.getText().equals("O") &&
				 btn6.getText().equals("O") )
		{
			player2Win = true;
		}
		else if( btn7.getText().equals("O") &&
				 btn8.getText().equals("O") &&
				 btn9.getText().equals("O") )
		{
			player2Win = true;
		}
		else
		{
			player1Win = false;
			player2Win = false;
		}
	}
	
	
	public class ButtonListener implements ActionListener
	{

		
		public void actionPerformed(ActionEvent pressed) 
		{
			//every time a button is clicked, we get  closer to end game.			
			updateButton((JButton)pressed.getSource());
			
			if(num_of_turns == MAX_TURN)
			{
				winCondition();
				
			}
			
			if(num_of_turns == 5 || num_of_turns == 6 || num_of_turns == 7 || num_of_turns == 8)
			{
				winCondition();
			}
			
			
			

			
		}
	

		
	}//close inner class
	
	public static void updateButton(JButton btn){
		
		num_of_turns++;
		
		if(num_of_turns % 2 == 0)
		{
			xo = "X";
		}
		else
		{
			xo = "O";
		}
		
		btn.setText(xo);
		//XO playerMoves = new XO(xo);
		btn.setEnabled(false);
		//Add it to the disabled list
		//Send the button to the other client
		XO xo = new XO(btn.getName());
		ChatClient.sendXO(xo);
		
	}
	
	
	public static JButton getBtn(String btnName)
	{
		JButton myBtn = null;
		

		
			for(int i = 0; i<btnList.size(); i++)
			{
				if(btnList.get(i).getName().equals(btnName))
				{
					myBtn = btnList.get(i);
				}
			}
		
		return myBtn;
	}

}//close outer class
