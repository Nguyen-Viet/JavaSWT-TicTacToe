package serverSide;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
/**
 * 
 * @author 636494 - Viet Nguyen
 *
 */
public class TicTacToeServer {
	
	//************Server needs to have a main method*****************
	public static void main(String [] args)
	{
		
		//This Holds player 1 and player 2 socket. Which will enable a connection.
		ArrayList<Socket> socketList = new ArrayList<Socket>(2);
		
		
		try{
			ServerSocket serverSocket = new ServerSocket(5555);
			System.out.println("Server up and running");
			
			while(true)
			{
				Socket clientSocket = serverSocket.accept(); //wait till player connect
				socketList.add(clientSocket);
				
				if(socketList.size() == 2)
				{
					ClientHandler clientHandler = new ClientHandler( socketList.get(0), 
																	 socketList.get(1) );
					
					Thread threadHandler = new Thread( clientHandler );
					
					threadHandler.start(); //begin the task that was sent to the thread
					socketList.clear();	   //clearing the list here allows for the next set of game
				}
			}
			
		}
		catch(SocketException e)
		{
			e.printStackTrace();
		}
		catch( IOException e)
		{
			e.printStackTrace();
		}
		
	}//close main method
}//end
