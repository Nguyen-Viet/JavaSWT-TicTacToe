package serverSide;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;

import utilities.InputListener;
import utilities.Message;

public class ClientHandler implements Runnable, Observer
{
	
	
	private Socket 					clientSocket1;
	private Socket 					clientSocket2;
	private ObjectOutputStream		oos1;
	private ObjectOutputStream		oos2;
	private InputListener			lis1; //client 1
	private InputListener			lis2; //client 2
	
	
	
	public ClientHandler(Socket clientSocket1, Socket clientSocket2)
	{
		this.clientSocket1 = clientSocket1;
		this.clientSocket2 = clientSocket2;
		
		try
		{
			//get ready to send out to InputListener
			oos1 = new ObjectOutputStream( clientSocket1.getOutputStream() );	//client 1 stream
			oos2 = new ObjectOutputStream( clientSocket2.getOutputStream() );	//client 2 stream
			
		}
		catch( IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public void run()
	{
		//prepare the job
		lis1 = new InputListener(1, clientSocket1, this); 	//client 1
		lis2 = new InputListener(2, clientSocket2, this);	//client 2	
		
		
		Thread thread1 = new Thread(lis1);	//client 1
		thread1.start();					//go to run() for client 1
		Thread thread2 = new Thread(lis2);	//client 2
		thread2.start();					//go to run() for client 2
		
		
		
		try
		{
			Message msg = new Message( "Connected", "You can start chatting!", new Date() );
			
			oos1.writeObject(msg);	//let client 1 know they are connected
			oos2.writeObject(msg);	//let client 2 know they are connected
			
			while(clientSocket1.isConnected() && clientSocket2.isConnected());
			
				//close connection to set up for next set of players
				clientSocket1.close();
				clientSocket2.close();
				oos1.close();
				oos2.close();
			
			
		}
		catch(SocketException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * This method relay message to the opponent
	 * 
	 */
	@Override
	public void update(Observable ob, Object o) 
	{
			InputListener listener = (InputListener)ob;
			
			try
			{
				if(listener.getListenerNumber() == 1)
				{
					oos2.writeObject(o); //write message to client 2
				}
				else
				{
					oos1.writeObject(o);	//write message to client 1
				}
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}	
	}
	
}//end
