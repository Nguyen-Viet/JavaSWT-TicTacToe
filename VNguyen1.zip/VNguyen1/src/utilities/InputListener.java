package utilities;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Observable;
import java.util.Observer;

// TODO: Auto-generated Javadoc
/**
 * The listener interface for receiving input events.
 * The class that is interested in processing a input
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addInputListener<code> method. When
 * the input event occurs, that object's appropriate
 * method is invoked.
 *
 * @see InputEvent
 */
public class InputListener extends Observable implements Runnable 
{
	
	
	
	private ObjectInputStream	ois; 				//the reader for incoming messages
	private int 				listenerNumber;		//player ID
	private Socket 				socket;
	

	
	
	/**
	 * Instantiates a new input listener.
	 *
	 * @param socket the socket
	 * @param observer the observer
	 */
	public InputListener(Socket socket, Observer observer)
	{
		listenerNumber = 0;
		this.socket = socket;
		
		/*
		 * this is how the observable (InputListener) 
		 * knows which update() to call from the many observers!!
		 */
		this.addObserver(observer);
		
	}
	

	/**
	 * Instantiates a new input listener.
	 *
	 * @param listenerNumber the listener number
	 * @param socket the socket
	 * @param observer the observer
	 */
	public InputListener(int listenerNumber, Socket socket, Observer observer)
	{
		this.listenerNumber = listenerNumber;
		this.socket = socket;
		this.addObserver(observer);
	}
	
	
	
	/**
	 * Gets the listener number.
	 *
	 * @return the listener number
	 */
	public int getListenerNumber()
	{
		return listenerNumber;
	}
	
	/**
	 * Sets the listener number.
	 *
	 * @param listenerNumber the new listener number
	 */
	public void setListenerNumber(int listenerNumber)
	{
		this.listenerNumber = listenerNumber;
	}
	
	
	/**
	 * *******************************************************************.
	 */
	public void run()
	{
		try
		{
			//reading messages from the stream
			ois = new ObjectInputStream(socket.getInputStream());
		
			while(true)
			{
				Object o = (Object)(ois.readObject());

				
				//call update() from correct observer
				//that we have read in an object from the stream
				setChanged();
				notifyObservers(o);
				
				
				
				if(o.getClass() == Message.class)
				{
					Message msg = (Message) o;
					/*
					 * when we hit the disconnect button on the GUI,
					 * we create a message object that holds userName, message,
					 * and the timeStamp. If we have disconnected then just
					 * stop reading and close connection 
					 */
					if(msg.getMessage().compareTo("has disconnected.") == 0)
					{
						ois.close();
						socket.close();
					}
				}
			}
			
			
		}
		catch(SocketException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}

	}//close run
	/**********************************************************************/
	
}//close 
