package utilities;

import java.io.Serializable;

import javax.swing.JButton;

public class XO implements  Serializable
{
	
	private static final long serialVersionUID = -6635341076366698128L;
	private String btnName;
	
	
	public XO(String btnName)
	{
		this.btnName = btnName;
	}
	
	
	public String getBtnName()
	{
		return btnName;
	}
	
	public void setBtnName(String btnName)
	{
		this.btnName = btnName;
	}

}
