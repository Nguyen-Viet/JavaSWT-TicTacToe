package utilities;

import java.io.Serializable;
import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class Message.
 */
public class Message implements Serializable
{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6635341076366698125L;
	
	private String 			user;
	private String 			message;
	private Date 			loggedTime;
	private String			xo;
	
	
	/**
	 * Instantiates a new message.
	 *
	 * @param user the user
	 * @param message the message
	 * @param loggedTime the logged time
	 */
	public Message(String user, String message, Date loggedTime )
	{
		this.user = user;
		this.message = message;
		this.loggedTime = loggedTime;
	}
	
	
	public Message(String xo)
	{
		this.xo = xo;
		
	}
	
	public String getXO()
	{
		return xo;
	}
	
	public void setXO(String xo)
	{
		this.xo = xo;
	}

	
	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	public String getUser() 
	{
		return user;
	}

	/**
	 * Sets the user.
	 *
	 * @param user the new user
	 */
	public void setUser(String user) 
	{
		this.user = user;
	}

	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) 
	{
		this.message = message;
	}

	/**
	 * Gets the logged time.
	 *
	 * @return the logged time
	 */
	public Date getLoggedTime() 
	{
		return loggedTime;
	}

	/**
	 * Sets the logged time.
	 *
	 * @param loggedTime the new logged time
	 */
	public void setLoggedTime(Date loggedTime) 
	{
		this.loggedTime = loggedTime;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() 
	{
		return "Message [user=" + user + ", message=" + message + ", loggedTime=" + loggedTime + "]";
	}
	
}
