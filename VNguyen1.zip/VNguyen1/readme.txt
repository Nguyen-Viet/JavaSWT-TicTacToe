Step1:
Launch VNguyen1Server.jar to start up the server application

Step2:
Launch VNguyen1.jar to start up game application

Step3:
Hit connect button and enter your desired username

Step4: 
Wait for opponent to connect

Step 5:
Play the game (tic-tac-toe)